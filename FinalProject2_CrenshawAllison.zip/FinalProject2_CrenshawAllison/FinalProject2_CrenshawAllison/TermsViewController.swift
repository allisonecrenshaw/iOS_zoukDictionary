import Foundation
import UIKit

class TermsViewController: UIViewController {
    var term: String = "Terms"
    @IBOutlet weak var BackButton: UIButton!
    @IBOutlet weak var TermsStack: UIStackView!
    @IBOutlet weak var MergulhoStack: UIStackView!
    @IBOutlet weak var CambreStack: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
    
    @IBAction func MergulhoClicked(_ sender: Any) {
        term = "Mergulho"
        updateUI()
    }
    
    @IBAction func CambreClicked(_ sender: Any) {
        term = "Cambre"
        updateUI()
    }
    
    @IBAction func BackButtonClicked(_ sender: Any) {
        term = "Terms"
        updateUI()
    }
    
    func updateUI() {
        if term == "Terms" {
            // hide terms and back button
            BackButton.isHidden = true
            MergulhoStack.isHidden = true
            CambreStack.isHidden = true
            // show home screen
            TermsStack.isHidden = false
        }
        else if term == "Mergulho" {
            MergulhoStack.isHidden = false
            TermsStack.isHidden = true
            BackButton.isHidden = false
        }
        else if term == "Cambre" {
            CambreStack.isHidden = false
            TermsStack.isHidden = true
            BackButton.isHidden = false
        }
    } // end updateUI()
} // end class

